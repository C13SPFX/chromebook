SaveEdit requires the full .NET Framework 4, which can be downloaded from
  http://www.microsoft.com/download/en/details.aspx?id=17851

Most UI interface icons are courtesy of Fugue Icons available at
  http://p.yusukekamiyamane.com/
